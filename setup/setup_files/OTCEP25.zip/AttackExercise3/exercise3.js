const { exec } = require('child_process');

// Function to create a scheduled task
function createScheduledTask() {
    // PowerShell equivalent: schtasks /create /sc once /tn MaliciousTask /tr calc.exe /st 23:59
    const taskName = 'MaliciousTask';
    const taskAction = 'calc.exe';
    const scheduleTime = '23:59';
    
    // Build the schtasks command
    const command = `schtasks /create /sc once /tn "${taskName}" /tr "${taskAction}" /st ${scheduleTime}`;
    
    console.log(`Creating scheduled task: ${taskName}`);
    console.log(`Command: ${command}`);
    
    // Execute the command
    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error creating scheduled task: ${error.message}`);
            return;
        }
        
        if (stderr) {
            console.error(`stderr: ${stderr}`);
            return;
        }
        
        console.log(`Success: ${stdout}`);
        console.log(`Scheduled task "${taskName}" created successfully!`);
    });
}

// Execute the function
createScheduledTask(); 